
Research Coach Website (Free Setup)

1. Upload this folder to a GitHub repository
2. Go to vercel.com
3. Import the repository
4. Click Deploy

Edit app/page.tsx to change your content.
