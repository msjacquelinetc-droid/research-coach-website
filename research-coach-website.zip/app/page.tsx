
export default function Home() {
  return (
    <main style={{ padding: '40px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Research Coaching Services</h1>
      <p>
        Professional research coaching and data analysis support from proposal
        development to full research projects, including qualitative and
        quantitative analysis.
      </p>
      <p>
        Contact: <a href="mailto:you@example.com">you@example.com</a>
      </p>
    </main>
  );
}
